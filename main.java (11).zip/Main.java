import java.util.Scanner;
class Main 
{
    public static void main(String[]args)
    {
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the number elements in an array:");
        int n=s.nextInt();
        int[]num=new int[n];
        System.out.println("Enter the elements in an array:");
        for(int i=0;i<n;i++)
        {
            num[i]=s.nextInt();
        }
        System.out.println("Enter the element to find:");
        int tar=s.nextInt();
        int index=FindElements(num,tar);
        if(index!=-1)
        {
            System.out.println("The element is found:");
        }
        else
        {
            System.out.println("The element is not found:");
        }
        s.close();
    }
    private static int FindElements(int[]num,int tar)
    {
        for(int i=0;i<num.length;i++)
        {
            if(num[i]==tar)
            {
                return i;
            }
        }
        return -1;
    }
}