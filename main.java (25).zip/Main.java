import java.util.Arrays;
import java.util.Scanner;
class Main 
{
    public static void main(String[]args)
    {
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the size of the array:");
        int n=s.nextInt();
        if(n<3)
        {
            System.out.println("Array must have atleast 3 unique elements:");
            return;
        }
        int [] arr=new int[n];
        System.out.println("Enter the elements of the array:");
        for(int i=0;i<n;i++)
        {
            arr[i]=s.nextInt();
        }
        int maxProduct=findMaxProduct(arr);
        System.out.println("The maximum product of three numbers:" + maxProduct);
        s.close();
    }
    public static int findMaxProduct(int[]arr)
    {
        Arrays.sort(arr);
        int n=arr.length;
        int p1=arr[n-1]*arr[n-2]*arr[n-3];
        int p2=arr[0]*arr[1]*arr[n-1];
        return Math.max(p1,p2);
    }
}