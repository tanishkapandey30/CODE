import java.util.Scanner;
class Main 
{
    public static void main(String[]args)
    {
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the number of persons (N):");
        int n=s.nextInt();
        if(n<=0)
        {
            System.out.println("Number of persons must be a positive integer:");
            return;
        }
        long perm=factorial(n-1);
        System.out.println("Number of distinct circular permutations for" + n + "persons:" + perm);
        s.close();
    }
    public static long factorial(int num)
    {
        if(num==0 || num==1)
        {
            return 1;
        }
        long result=1;
        for(int i=2;i<=num;i++)
        {
            result*=i;
        }
        return result;
    }
}