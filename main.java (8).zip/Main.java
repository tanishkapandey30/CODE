import java.util.Scanner;
class Main 
{
    public int[]twosum(int[]num,int target)
    {
        for(int i=0;i<num.length;i++)
        {
            for(int j=i+1;j<num.length;j++)
            {
                if(num[i]+num[j]==target)
                {
                    return new int[]{i,j};
                }
            }
        }
        return null;
    }
    public static void main(String[]args)
    {
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the number of elements in an array:");
        int n=s.nextInt();
        int[]num=new int[n];
        System.out.println("Enter the elements of an array:");
        for(int i=0;i<n;i++)
        {
            num[i]=s.nextInt();
        }
        System.out.println("Enter the target value:");
        int target=s.nextInt();
        Main sol=new Main();
        int[] result=sol.twosum(num,target);
        if(result!=null)
        {
            System.out.println("Indices of the two numbers that add up to the target are:"+ result[0]+ "and" + result[1]);
        }
        else 
        {
            System.out.println("no two numbers add up to the target:");
        }
       s.close();
    }
}