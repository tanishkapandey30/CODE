import java.util.Scanner;
class Main 
{
    public static void main(String [] args)
    {
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the coeffcients a,b and c:");
        double a=s.nextDouble();
        double b=s.nextDouble();
        double c=s.nextDouble();
        double dis=b*b-4*a*c;
        if(a==0)
        {
            System.out.println("Coefficient 'a' cannot be zero:");
        }
        else
        {
            if(dis>0)
            {
                double r1=(-b + Math.sqrt(dis))/(2*a);
                double r2=(-b - Math.sqrt(dis))/(2*a);
                System.out.printf("Roots are real and different:%2f and %2f\n",r1,r2);
            }
            else if(dis==0)
            {
                double r=-b/(2*a);
                System.out.printf("Roots are real and same: %2f\n",r);
            }
            else 
            {
                double rp=-b/(2*a);
                double ip=Math.sqrt(-dis)/(2*a);
                System.out.printf("Roots are complex:%2f + %2fi and %2f - %2fi\n",rp,ip,rp,ip);
            }
        }
        s.close();
    }
}