import java.util.Scanner;
class Main 
{
    public static void main(String [] args)
    {
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the main string:");
        String mainS=s.nextLine();
        System.out.println("Enter the substring to check:");
        String subS=s.nextLine();
        if(mainS.contains(subS))
        {
            System.out.println(subS + "is substring of" + mainS);
        }
        else
        {
            System.out.println(subS + "is not a substring of" + mainS);
        }
        s.close();
    }
}