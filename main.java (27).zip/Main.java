import java.util.Scanner;
class Main 
{
    public static void main(String[]args)
    {
        Scanner s=new Scanner(System.in);
        System.out.println("Enter a number:");
        String i=s.nextLine();
        int sum=calSumOfDigits(i);
        System.out.println("Sum of digits:" + sum);
        s.close();
    }
    public static int calSumOfDigits(String num)
    {
        int sum=0;
        for(char ch:num.toCharArray())
        {
            if(Character.isDigit(ch))
            {
                sum+=Character.getNumericValue(ch);
            }
        }
        return sum;
    }
}