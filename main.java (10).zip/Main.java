import java.util.Scanner;
class Main 
{
    public static void main(String[]args)
    {
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the number of elements in an array:");
        int n=s.nextInt();
        int[]nums=new int[n];
        System.out.println("Enter the elements of an array:");
        for(int i=0;i<n;i++)
        {
            nums[i]=s.nextInt();
        }
        boolean sorted=ArraySorted(nums);
        if(sorted)
        {
            System.out.println("The array is sorted in ascending order:");
        }
        else 
        {
            System.out.println("The array is not sorted in ascending order:");
        }
        s.close();
    }
    private static boolean ArraySorted(int[]nums)
    {
        for(int i=1;i<nums.length;i++)
        {
            if(nums[i-1]>nums[i])
            {
                return false;
            }
        }
        return true;
    }
}