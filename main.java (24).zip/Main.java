import java.util.Scanner;
class Main 
{
    public static void main(String[]args)
    {
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the string:");
        String i=s.nextLine();
        String sortedString=sortString(i);
        System.out.println("Sorted String:" + sortedString);
        s.close();
    }
    public static String sortString(String s)
    {
        char[] chars=s.toCharArray();
        java.util.Arrays.sort(chars);
        return new String(chars);
    }
}