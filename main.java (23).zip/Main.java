import java.util.Scanner;
import java.util.Stack;
class Main 
{
    public static void main(String[]args)
    {
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the string:");
        String input=s.nextLine();
        String result=removeAdjacentDuplicates(input);
        System.out.println("String after removing adjacent duplicates:" + result);
        s.close();
    }
    public static String removeAdjacentDuplicates(String s)
    {
        Stack<Character>stack=new Stack<>();
        for(char ch: s.toCharArray())
        {
            if(!stack.isEmpty() && stack.peek()==ch)
            {
                stack.pop();
            }
            else 
            {
                stack.push(ch);
            }
        }
        StringBuilder sb=new StringBuilder();
        for(char ch:stack)
        {
            sb.append(ch);
        }
        return sb.toString();
    }
}