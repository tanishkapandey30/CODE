import java.util.Scanner;
class Main 
{
    public static void main(String[]args)
    {
        Scanner s=new Scanner(System.in);
        int n=s.nextInt();
        if(n<=0)
        {
        System.out.println("Array size must be greater than 0:");
        return;
        }
        int [] arr = new int[n];
        System.out.println("Enter the elements:");
        for(int i=0;i<n;i++)
        {
            arr[i]=s.nextInt();
        }
        int c=findCandidate(arr);
        if(isMajority(arr,c))
        {
            System.out.println("The Majority Element is:" + c);
        }
        else
        {
            System.out.println("No Majority Element found:");
        }
        s.close();
    }
    public static int findCandidate(int[]nums)
    {
        int c=nums[0];
        int count=1;
        for(int i=0;i<nums.length;i++)
        {
            if(nums[i]==c)
            {
                count++;
            }
            else
            {
                count--;
                if(count==0)
                {
                    c=nums[i];
                    count=1;
                }
            }
        }
        return c;
    }
    public static boolean isMajority(int[]nums,int c)
    {
        int count=0;
        for(int num : nums)
        {
            if(num==c)
            {
                count++;
            }
        }
        return count>nums.length/2;
    }
}