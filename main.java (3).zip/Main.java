class Main 
{
    public static void main(String[] args)
    {
        int num=222, onum,rem,result=0;
        onum=num;
        while(onum!=0)
        {
            rem=onum%10;
            result+=Math.pow(rem,3);
            onum=onum/10;
        }
        if(result==num)
            System.out.println(num+ "is an armstrong number");
        else
            System.out.println(num+ "is not a armstrong number");
        
    }
}