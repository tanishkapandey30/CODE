import java.util.Scanner;
import java.util.TreeSet;
class Main 
{
    public static void main(String [] args)
    {
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the size of the array:");
        int n=s.nextInt();
        if(n<3)
        {
            System.out.println("Array must have atleast 3 elements:");
            return;
        }
        int [] arr=new int [n];
        System.out.println("Enter the elements in the array:");
        for(int i=0;i<n;i++)
        {
            arr[i]=s.nextInt();
        }
        Integer thirdMax=findThirdMax(arr);
        if(thirdMax!=null)
        {
            System.out.println("The third maximum number is:" + thirdMax);
        }
        else 
        {
            System.out.println("There are less than 3 unique numbers in the array:");
        }
        s.close();
    }
    public static Integer findThirdMax(int [] arr)
    {
        TreeSet<Integer>sortedSet=new TreeSet<>();
        for(int num : arr)
        {
            sortedSet.add(num);
        }
        if(sortedSet.size()<3)
        {
            return null;
        }
        sortedSet.pollLast();
        sortedSet.pollLast();
        return sortedSet.last();
    }
}
