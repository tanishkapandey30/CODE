import java.util.Scanner;
class Main 
{
    public static void main(String[]args)
    {
        Scanner s = new Scanner(System.in);
        System.out.println("Enter the string:");
        String inputString=s.nextLine();
        System.out.println("Enter the character to remove:");
        char charToRemove=s.next().charAt(0);
        String result=removeCharacter(inputString,charToRemove);
        System.out.println("String after removing the character:"+result);
        s.close();
    }
    private static String removeCharacter(String str, char charToRemove)
    {
        return str.replace(String.valueOf(charToRemove),"");
    }
}