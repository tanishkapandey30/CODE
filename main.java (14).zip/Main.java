import java.util.*;
class Main 
{
    public static void main(String[]args)
    {
        Scanner s=new Scanner(System.in);
        System.out.println("Enter elements seperated by spaces:");
        String input=s.nextLine();
        String[]elements=input.split("\\s+");
        Map<String,Integer>frequencyMap=new HashMap<>();
        for(String element:elements)
        {
            frequencyMap.put(element,frequencyMap.getOrDefault(element,0)+1);
        }
        List<Map.Entry<String,Integer>>sortedEntries=new ArrayList<>(frequencyMap.entrySet());
        sortedEntries.sort((entry1,entry2)->entry2.getValue().compareTo(entry1.getValue()));
        System.out.println("Elements sorted by frequency:");
        for(Map.Entry<String,Integer>entry:sortedEntries)
        {
            System.out.println(entry.getKey()+ ":" + entry.getValue());
        }
        s.close();
    }
}