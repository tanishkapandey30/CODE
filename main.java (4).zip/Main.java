class Main 
{
    public static void main(String [] args)
    {
        int i,m=0,flag=0;
        int n=3;
        m=n/2;
        if(n==0||n==1)
        {
             System.out.println("Not a Prime Number");
        }
        else{
            for(i=2;i<n;i++)
            {
                if(n%i==0)
                {
                    System.out.println(n + "Not a Prime Number");
                    flag=1;
                    break;
                }
            }
            if(flag==0)
            {
                System.out.println(n + "Prime Number");
            }
        }
    }       
}