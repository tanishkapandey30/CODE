import java.util.Scanner;
class Main 
{
    public static void main(String[]args)
    {
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the number of elements:");
        int n=s.nextInt();
        if(n<2)
        {
            System.out.println("Array size must be at least 2");
            return;
        }
        int [] arr=new int[n];
        System.out.println("Enter the elenments:");
        for(int i=0;i<n;i++)
        {
            arr[i]=s.nextInt();
        }
        int[]result=findSmallest(arr);
        if(result[0]==Integer.MAX_VALUE)
        {
            System.out.println("Not enough distinct elements to find the second smallest");
        }
        else
        {
            System.out.println("The smallest element is:" + result[0]);
            System.out.println("The second smallest element is:" + result[1]);
        }
        s.close();
    }
    public static int[] findSmallest(int [] nums)
    {
        int s=Integer.MAX_VALUE;
        int ss=Integer.MAX_VALUE;
        for(int num : nums)
        {
            if(num<s)
            {
                ss=s;
                s=num;
            }
            else if(num>s && num<ss)
            {
                ss=num;
            }
        }
        return new int[]{s,ss};
    }
}