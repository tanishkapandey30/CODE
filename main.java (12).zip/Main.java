import java.util.Scanner;
import java.util.Arrays;
class Main 
{
    public static void main(String[]args)
    {
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the number of elements in an array:");
        int n= s.nextInt();
        int[]num=new int[n];
        System.out.println("Enter the elements in an array:");
        for(int i=0;i<n;i++)
        {
            num[i]=s.nextInt();
        }
        System.out.println("Enter the element to add in an array:");
        int newElement=s.nextInt();
        int[]newArray=new int[num.length+1];
        for(int j=0;j<num.length;j++)
        {
            newArray[j]=num[j];
        }
        newArray[num.length]=newElement;
        System.out.println("Array after adding the new element:");
        System.out.println(Arrays.toString(newArray));
        s.close();
    }
}