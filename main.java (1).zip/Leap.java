import java.time.Year;
public class Leap 
{
    public static boolean checkYear(int y)
    {
        Year x=Year.of(y);
        return x.isLeap();
    }
    public static void main(String[] args)
    {
        int year=2000;
        if(checkYear(year))
        {
            System.out.println("Leap Year");
        }
        else 
        {
            System.out.println("Not  a Leap Year");
        }
    }
}