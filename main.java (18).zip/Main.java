import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
class Main 
{
    public static void main(String [] args)
    {
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the string:");
        String inputString=s.nextLine();
        Map<Character,Integer>frequencyMap=getCharacterFrequency(inputString);
        System.out.println("Character frequencies:");
        for(Map.Entry<Character,Integer>entry:frequencyMap.entrySet())
        {
            System.out.println(entry.getKey()+":"+entry.getValue());
        }
        s.close();
    }
    private static Map<Character,Integer>getCharacterFrequency(String str)
    {
        Map<Character,Integer>frequencyMap=new HashMap<>();
        for(char c:str.toCharArray())
        {
            frequencyMap.put(c,frequencyMap.getOrDefault(c,0)+1);
        }
        return frequencyMap;
    }
}